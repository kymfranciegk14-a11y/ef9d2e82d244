// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sum long-range forces"); }
int main(){
  announce();
  return lionss_run_workload("ewald-sum");
}
