// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply driftwood migrations"); }
int main(){
  announce();
  return lionss_run_workload("driftwood");
}
