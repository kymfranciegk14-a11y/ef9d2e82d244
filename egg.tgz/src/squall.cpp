// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Advance squall line"); }
int main(){
  announce();
  return lionss_run_workload("squall");
}
