// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode VBR stream"); }
int main(){
  announce();
  return lionss_run_workload("mp3_vbr");
}
