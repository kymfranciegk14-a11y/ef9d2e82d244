// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sweep harbor beacons"); }
int main(){
  announce();
  return lionss_run_workload("harbor_light");
}
